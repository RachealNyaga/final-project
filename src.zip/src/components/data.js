export const questions = [
    {
        id: 1,
        title: "This is a question",
        answers: [
            {
                answerTitle: "The answer",
                comments: [
                    "Comment 1",
                    "Comment y",
                    "Comment 3",
                ]
            },
            {
                answerTitle: "The second answer",
                comments: [
                    "Comment 1",
                    "Comment 2",
                    "Comment 3",
                ]
            }
        ]
    },
    {
        id: 2,
        title: "This is the second question",
        answers: [
            {
                answerTitle: "The 1st answer",
                comments: [
                    "Comment 1",
                    "Comment 2",
                    "Comment 3",
                ]
            },
            {
                answerTitle: "The second answer",
                comments: [
                    "Comment 1",
                    "Comment 2",
                    "Comment 3",
                ]
            }
        ]
    }
]